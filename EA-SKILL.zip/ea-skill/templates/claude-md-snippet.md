## EA-SKILL 嵌入式工具（动态加载）

> 工具路径已通过 `/ea setup` 注册。当对话提到以下关键词时，
> **按需读取**对应命令文档了解用法（不要假设参数）：

| 关键词 | 命令文档 |
|--------|----------|
| 编译 / build / 构建 | `~/.claude/skills/ea-skill/commands/build.md` |
| 烧录 / flash / 下载 / 固件 | `~/.claude/skills/ea-skill/commands/flash.md` |
| 串口 / serial / 抓取 / 监控 | `~/.claude/skills/ea-skill/commands/serial.md` |
| RTT / 断点 / debug / 内存监视 / OpenOCD / ST-Link / DAP | `~/.claude/skills/ea-skill/commands/debug.md` |
| SVD / 寄存器 / 位域 / 外设配置 / 芯片手册 | `~/.claude/skills/ea-skill/commands/svd.md` |
| 逻辑分析仪 / LA / Saleae / 时序分析 | `~/.claude/skills/ea-skill/commands/la.md` |
| 示波器 / scope / 波形 / SCPI / 电压测量 | `~/.claude/skills/ea-skill/commands/scope.md` |
| 内存 / size / Flash 占用 / RAM 使用 / 超限预警 | `~/.claude/skills/ea-skill/commands/size.md` |
| Map 文件 / 符号地址 / 内存排行 / 资源分析 | `~/.claude/skills/ea-skill/commands/map.md` |
